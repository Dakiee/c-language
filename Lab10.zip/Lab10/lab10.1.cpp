#include<stdio.h>
#include<math.h>

struct Triangle {
    int a, b, c;
} tra1, tra2;

int main() {
    printf("1r gurvaljin a= ");
    scanf("%d", &tra1.a);
    printf("1r gurvaljin b= ");
    scanf("%d", &tra1.b);
    printf("1r gurvaljin c= ");
    scanf("%d", &tra1.c);

    printf("2r gurvaljin a= ");
    scanf("%d", &tra2.a);
    printf("2r gurvaljin b= ");
    scanf("%d", &tra2.b);
    printf("2r gurvaljin c= ");
    scanf("%d", &tra2.c);

    int p, S, S2;

    p = (tra1.a + tra1.b + tra1.c)/2;
    S = (sqrt(p * (p - tra1.a) * (p - tra1.b) * (p - tra1.c)));

    p = (tra2.a + tra2.b + tra2.c)/2;
    S2 = (sqrt(p * (p - tra2.a) * (p - tra2.b) * (p - tra2.c)));

    if( S >= S2)
        printf("Tom gurvaljin bol 1r gurvaljin: %d", S);
    else printf("Tom gurvaljin bol 2r gurvaljin: %d", S2);

    return 0; 

}
