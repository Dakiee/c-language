#include <stdio.h>
#include <stdlib.h>
#include <math.h>

struct Point {
    int x, y;
};


double getDistance(struct Point a, struct Point b)
{
    double distance;
    distance = sqrt((a.x - b.x) * (a.x - b.x) + (a.y-b.y) *(a.y-b.y));
    return distance;
}



int main()
{
    struct Point a, b;
    printf("a tsegiin coordinatuudiig oruulna uu: ");
    scanf("%d %d", &a.x, &a.y);
    printf("b tsegiin coordinatuudiig oruulna uu: ");
    scanf("%d %d", &b.x, &b.y);
    printf("a ba b tsegiin hoorondoh zai ni: %lf\n", getDistance(a, b));


    return 0;
}
#include<stdio.h>
#include<math.h>

struct Triangle {
    int a, b, c;
}tra1, tra2;

double find_area(Triangle g) {
    double p, s;

    p = (g.a + g.b + g.c)/2;
    s = sqrt(p * (p - g.a) * (p - g.b) * (p - g.c));

    return s;
}
