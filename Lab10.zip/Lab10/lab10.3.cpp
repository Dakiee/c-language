#include<stdio.h>
#include<math.h>

struct Triangle {
    int a, b, c;
}tra1, tra2;

double find_area(Triangle g) {
    double p, s;

    p = (g.a + g.b + g.c)/2;
    s = sqrt(p * (p - g.a) * (p - g.b) * (p - g.c));

    return s;
}

int main() {
    printf("1r gurvaljin a= ");
    scanf("%d", &tra1.a);
    printf("1r gurvaljin b= ");
    scanf("%d", &tra1.b);
    printf("1r gurvaljin c= ");
    scanf("%d", &tra1.c);

    printf("2r gurvaljin a= ");
    
    scanf("%d", &tra2.a);
    printf("2r gurvaljin b= ");
    scanf("%d", &tra2.b);
    printf("2r gurvaljin c= ");
    scanf("%d", &tra2.c);

    if(find_area(tra1) >= find_area(tra2))
        printf("1r gurvaljin tom");
    else printf("2r gurvaljin tom");

    return 0;
}
