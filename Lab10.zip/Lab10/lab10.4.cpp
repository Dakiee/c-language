#include<stdio.h>

struct Rational {
    int d, n;
};

typedef struct Rational Rational;

Rational add( Rational a, Rational b) {
    Rational result;
    result.d = a.d + b.d ;
    result.n = a.n + b.n;
    return result;
} 

Rational sub( Rational a, Rational b) ; 
Rational mult ( Rational a, Rational b) ; 
Rational div ( Rational a, Rational b) ; 
Rational simplify ( Rational a) ; 
void print ( Rational a) ; 

int Yrunhii(int m, int n) {
    int i, k;

    for(i = 1; i <= m || i <= n; i++) {
        if(m % i == 0)
            if(n % i == 0)
                k = i;
    }
    return k;
}

int main() {
    Rational a, b;

    a.d = 144;
    a.n = 266;


    b.d = 6;
    b.n = 18;

    Rational add(Rational a, Rational b);
    printf("%d, %d", add(a,b));

}
