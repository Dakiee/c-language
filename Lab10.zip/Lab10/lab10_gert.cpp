#include<stdio.h>
#include<string.h>
	 struct Student{
		char fname[20], lname[20],id[20];
		float golch;
	}d[20];

int main(){

	int n,m,old;
	scanf("%d",&n);
	typedef struct Student Student;

	void read_students (Student a[] , int n);
    void print_students (Student a[] , int n);
    int search_by_fname(Student a[] , int n, char fname[] );
	int search_by_lname(Student a[] , int n, char lname[] );
	int search_by_id(Student a[] , int n, char id [] );
	int search_by_golch(Student a[] , int n, float golch);
	void sort_by_golch (Student a[] , int n);

	Student stud[n];
	read_students(stud,n);

	do{
		printf("\n0.exit");
		printf("\n1.print_students");
		printf("\n2.search_by_fname");
		printf("\n3.search_by_lname");
		printf("\n4.search_by_id");
		printf("\n5.search_by_golch");
		printf("\n6.sort_by_golch\n");
		scanf("%d",&m);
		char fname[20];
		char lname[20];
		char id[20];
		float golch;
		switch(m){
			case 1: print_students (stud,n);  break;
			case 2:
					scanf("%s",fname);

					old =search_by_fname(stud,n, fname);
					if(old!=-1){
						printf("oldloo - > %s",stud[old].fname);
					}
					else{
					printf("%d",old);
					}
					break;
					//printf("%d",search_by_fname(stud,n, fname));break;
			case 3:
					scanf("%s",lname);

					old =search_by_lname(stud,n, lname);
					if(old!=-1){
						printf("oldloo - > %s",stud[old].lname);
					}
					else{
					printf("%d",old);
					}
					break;

					//printf("%d",search_by_lname(stud,n, lname));break;
			case 4:
					scanf("%s",id);

					old =search_by_id(stud,n, id);
					if(old!=-1){
						printf("oldloo - > %s",stud[old].id);
					}
					else{
					printf("%d",old);
					}
					break;
					//printf("%d",search_by_id(stud,n, id));break;
			case 5:
					scanf("%f",&golch);
					old =search_by_golch(stud,n,golch);
					if(old!=-1){
						printf("oldloo - >%s",stud[old].fname);
					}
					else{
					printf("%d",old);
					}
					break;
			case 6: sort_by_golch(stud,n);break;
		}
	} while(m!=0);

}
	void read_students (struct Student a[] , int n){
		int i;
		char s[20];
		for(i=0;i<n;i++){
			puts("id=?");
			scanf("%s",s);
			strcpy(a[i].id,s);
			puts("Fname=?");
			scanf("%s",s);
			strcpy(a[i].fname,s);
			puts("Lname=?");
			scanf("%s",s);
			strcpy(a[i].lname,s);
			float b;
			puts("Golch=?");
			scanf("%f",&b);
			a[i].golch=b;
		}
	}
    void print_students (struct Student a[] , int n){
		int i;
		char s[20];
		for(i=0;i<n;i++){
			printf("\nid: %s\n",a[i].id);
			printf("fname: %s\n",a[i].fname);
			printf("lname: %s\n",a[i].lname);
			printf("Golch: %f\n",a[i].golch);
			printf("--------------------------");
		}
	}

	int search_by_fname(struct Student a[] , int n, char fname[] ){
		int i;
		char s[20];
		for(i=0;i<n;i++){
			if(!strcmp(a[i].fname,fname)){
				return i;
			}
		}
		return -1;
	}

	int search_by_lname(struct Student a[] , int n, char lname[] ){
		int i;
		char s[20];
		for(i=0;i<n;i++){
			if(!strcmp(a[i].lname,lname)){
				return i;
			}
		}
		return -1;
	}

	int search_by_id(struct Student a[] , int n, char id[] ){
		int i;
		char s[20];
		for(i=0;i<n;i++){
			if(!strcmp(a[i].id,id)){
				return i;
			}
		}
		return -1;
	}

	int search_by_golch(struct Student a[] , int n, float golch ){
		int i;
		char s[20];
		for(i=0;i<n;i++){
			if(a[i].golch==golch){
				return i;
			}
		}
		return -1;
	}

	void sort_by_golch (struct Student a[] , int n){
		int c,d;
		struct Student t;

		for (c = 0 ; c <n; c++) {
    	d = c;

    		while ( d > 0 && a[d-1].golch > a[d].golch) {
      			t = a[d];
      			a[d]   = a[d-1];
      			a[d-1] = t;
     			d--;
    		}
  		}
	}

